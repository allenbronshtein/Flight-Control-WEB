﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightRadar.Models
{
    public class Server
    {
        public long id { get; set; }
        public string ServerId { get; set; }
        public string ServerURL { get; set; }
    }
}
